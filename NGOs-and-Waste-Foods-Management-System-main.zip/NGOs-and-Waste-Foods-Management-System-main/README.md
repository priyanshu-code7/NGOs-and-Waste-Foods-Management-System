# NGO-WASTE-FOOD-MANAGEMENT-
Waste food management system 
